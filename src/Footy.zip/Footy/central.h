#ifndef CENTRAL_H_
#define CENTRAL_H_

#ifdef __cplusplus
extern "C" {
#endif

/**
* @brief   Main function of the program, search and retrieve a ball in a loop
*
*/
void central_control_loop(void);

#ifdef __cplusplus
}
#endif

#endif // CENTRAL_H_
